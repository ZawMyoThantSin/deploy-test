package com.test.TestProject.controller;

import com.test.TestProject.model.CourseDTO;
import com.test.TestProject.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class TestController {
    @Autowired
    private CourseService service;

    @GetMapping("/")
    public String index(){
        return "Hello World";
    }

    @PostMapping("/save")
    public CourseDTO save(@RequestBody CourseDTO courseDTO){
        System.out.println("In Controller: "+courseDTO);
        return service.save(courseDTO);
    }

    @GetMapping("/all")
    public List<CourseDTO> getAll(){
        return service.getAll();
    }

    @GetMapping("/{id}")
    private CourseDTO getById(@PathVariable("id")int id){
        return service.getById(id);
    }
}
