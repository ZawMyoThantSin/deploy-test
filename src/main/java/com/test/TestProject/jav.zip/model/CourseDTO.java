package com.test.TestProject.model;

import lombok.Data;

@Data
public class CourseDTO {
    private int id;
    private String name;
    private String duration;
    private int price;
}
